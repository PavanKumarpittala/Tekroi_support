   <!-- <div class="footer_part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer_iner text-center">
                    <p>2022 © Copyrights By <a href="https://tekroi.com/" style="color:#5947B2;">TEKROI</a></p>
                </div>
            </div>
        </div>
    </div>
</div> -->
</div>

<script type="text/javascript" src="{{asset('js/popper.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/metisMenu.js')}}"></script>
<script type="text/javascript" src="{{asset('js/main.js')}}"></script>

<script type="text/javascript" src="{{asset('js/dashboard_init.js')}}"></script>
<script type="text/javascript" src="{{asset('js/custom.js')}}"></script>
<script type="text/javascript" src="{{asset('js/constents.js')}}"></script>

<script type="text/javascript">
      var public_path = "{{url('/')}}";
</script>
   
  </body>
</html>