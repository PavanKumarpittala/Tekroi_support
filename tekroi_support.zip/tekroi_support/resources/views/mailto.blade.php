<pre>Dear <?php echo $body_data['name'];?>,

Welcome to TEKROI Supoort Portal, Please use below Credentials to Login to your Account.

<b>Login URL :</b> <a href="http://c360.zone/tekroi_support/">http://c360.zone/tekroi_support/</a>

<b>Email:</b>  <?php echo $body_data['email']; ?>

<b>Password:</b> Tekroi@2022

This is system generated email. Do not reply.
</pre>
