

<?php $__env->startSection('content'); ?>
<main class="app-content">
<div class="container">
    <div class="row">
        <div class="col-md-12">
           <?php if(session('status')): ?>
                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>Edit & Update Primary Contact Details
                        
                    </h4>
                </div>
                <div class="card-body">
             
                    <form action="<?php echo e(url('update_primary_contact/'.$details->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                       
                        <div class="form-group list">
                          <label for="name">Primary Contact:</label>
                           <input type="text" class="form-control" id="name" name="name" value="<?php echo e($details->contact_name); ?>"><br>
                          <input type="email" class="form-control" id="email" name="email" value="<?php echo e($details->contact_email); ?>"><br>
                          <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo e($details->contact_mobile); ?>"><br>
                          <input type="text" class="form-control" id="designation" name="designation" value="<?php echo e($details->contact_designation); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/tekroi_support/resources/views/edit_primary_contact.blade.php ENDPATH**/ ?>