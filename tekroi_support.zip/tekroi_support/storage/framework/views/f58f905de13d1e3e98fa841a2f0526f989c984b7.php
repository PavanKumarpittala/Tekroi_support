<?php if(isset($title)): ?>
<p><?php echo e($title ?? null); ?></p>
<?php endif; ?>

<?php if(isset($body)): ?>
<?php echo $body ?? null; ?>

<?php endif; ?>

<?php if(isset($ticket_id)): ?>
    <!-- <h4>Ticket Details</h4> -->
    <p><b>Ticket Id</b> : <?php echo e($ticket_id); ?></p>
    <p><b>Ticket Message</b> : </p>
    <p><?php echo $ticket_message; ?></p>
<?php endif; ?>

<?php /**PATH /var/www/html/tekroi_support/resources/views/emails/myTestMail.blade.php ENDPATH**/ ?>