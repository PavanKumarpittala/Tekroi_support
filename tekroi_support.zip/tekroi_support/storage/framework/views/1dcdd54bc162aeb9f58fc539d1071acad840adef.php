Ticket Subject : <?php echo e($params['subject']); ?>

Ticket Summary : <?php echo e($params['ticket_summary']); ?>


<?php /**PATH /var/www/html/tekroi_support/resources/views/emails/mail.blade.php ENDPATH**/ ?>