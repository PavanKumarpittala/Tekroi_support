<h1>Hi Gopinadh</h1>
<p>Sending Mail from Laravel.</p><?php /**PATH /var/www/html/tekroi_support/resources/views/mail.blade.php ENDPATH**/ ?>