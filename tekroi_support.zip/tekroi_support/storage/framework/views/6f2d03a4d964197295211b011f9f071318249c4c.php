<?php $__env->startSection('content'); ?>
<main class="app-content">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h4>Open Issues</h4>
                    <a href="<?php echo e(url('support_view')); ?>" target="_blank"><span class="text-danger float-right" style="font-size: 19px;margin-top: -31px;"><?php echo e($open_issues_count); ?></span></a>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Last Updated Timesheet</h4>
                    <a href="<?php echo e(url('timesheets_list')); ?>" target="_blank"><span class="text-danger float-right" style="font-size: 19px;margin-top: -31px;"><?php echo e($last_timesheet->created_at); ?></span></a>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tekroi_support\resources\views/home.blade.php ENDPATH**/ ?>