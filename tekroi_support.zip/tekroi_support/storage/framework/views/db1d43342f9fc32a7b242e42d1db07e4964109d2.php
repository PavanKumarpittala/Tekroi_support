<?php $__env->startSection('content'); ?>
<main class="app-content">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <?php if(Auth::user()->role == 1 || Auth::user()->role == 2 || Auth::user()->role == 3): ?>
                <div class="card-header">
                    <h4>Open Tickets</h4>
                </div>
                <div class="card-header">
                    <h4>Today</h4>
                    <a href="<?php echo e(url('support_view')); ?>" onclick="setStatusPeriod(0,'today')"><span class="text-danger float-right dashboard-stats-count"><?php echo e($open_issues['today']); ?></span></a>
                </div>
                <div class="card-header">
                    <h4>Yesterday</h4>
                    <a href="<?php echo e(url('support_view')); ?>" onclick="setStatusPeriod(0,'yesterday')"><span class="text-danger float-right dashboard-stats-count"><?php echo e($open_issues['yesterday']); ?></span></a>
                </div>
                <div class="card-header">
                    <h4>Last 7 Days</h4>
                    <a href="<?php echo e(url('support_view')); ?>" onclick="setStatusPeriod(0,'week')"><span class="text-danger float-right dashboard-stats-count"><?php echo e($open_issues['week']); ?></span></a>
                </div>
                <div class="card-header">
                    <h4>Last 30 Days </h4>
                    <a href="<?php echo e(url('support_view')); ?>" onclick="setStatusPeriod(0,'month')"><span class="text-danger float-right dashboard-stats-count"><?php echo e($open_issues['month']); ?></span></a>
                </div>
                <div class="card-header">
                    <h4>Beyond 30 Days </h4>
                    <a href="<?php echo e(url('support_view')); ?>" onclick="setStatusPeriod(0,'beyondmonth')"><span class="text-danger float-right dashboard-stats-count"><?php echo e($open_issues['beyondmonth']); ?></span></a>
                </div>
                <?php endif; ?>

            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Last Updated Timesheet</h4>
                    <a href="<?php echo e(url('timesheets_list')); ?>"><span class="text-danger float-right" style="font-size: 19px;margin-top: -31px;">
                      <?php echo e(date('d-m-Y H:i', strtotime($last_timesheet->created_at))); ?>

                       </span></a>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
   function setStatusPeriod(status, period)
   {
        sessionStorage.setItem('dashboardTicketStatus', status);
        sessionStorage.setItem('dashboardTicketPeriod', period);
   }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/tekroi_support/resources/views/home.blade.php ENDPATH**/ ?>