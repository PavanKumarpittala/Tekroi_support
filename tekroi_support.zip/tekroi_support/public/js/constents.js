//parameter names as per table
var CONS_Damaged = 2; 
var CONS_Broken = 1;
var CONS_Weevelled =  3;
var CONS_Foreign_Matter = 4; 
var CONS_Immature = 5;
var CONS_Shrivelled =6;
var CONS_Healthy =7;
